const products = [
    {
        maSP: "SP001",
        tenSP: "Laptop Dell",
        danhMuc: "Máy tính",
        soLuong: 10,
        donGia: 15000000
    },
    {
        maSP: "SP002",
        tenSP: "Chuột Logitech",
        danhMuc: "Phụ kiện",
        soLuong: 25,
        donGia: 250000
    }
];

let isShowDanhSach = true;

function toggleDanhSach() {
    isShowDanhSach = !isShowDanhSach;
    capNhatHienThiDanhSach();
}

function capNhatHienThiDanhSach() {
    const container = document.getElementById("khuVucDanhSach");
    if (container) {
        container.style.display = isShowDanhSach ? "block" : "none";
    }
    const btn = document.getElementById("btnHienThi");
    if (btn) {
        btn.innerHTML = isShowDanhSach ? " Ẩn danh sách" : " Hiển thị danh sách";
    }
}

function hienThiDanhSach() {
    const tableBody = document.getElementById("tableBody");
    tableBody.innerHTML = "";

    for (let i = 0; i < products.length; i++) {
        const sp = products[i];

        const row = document.createElement("tr");

        row.innerHTML = `
          <td>${sp.maSP}</td>
          <td>${sp.tenSP}</td>
          <td>${sp.danhMuc}</td>
          <td class="td-sl">${sp.soLuong}</td>
          <td class="td-gia">${sp.donGia.toLocaleString("vi-VN")} ₫</td>
        `;

        tableBody.appendChild(row);
    }

    capNhatHienThiDanhSach();
}

function anTatCaLoi() {
    const allErrors = document.querySelectorAll(".error-msg");
    for (let i = 0; i < allErrors.length; i++) {
        allErrors[i].style.display = "none";
    }
    document.getElementById("thongBaoLoi").style.display = "none";
}

function kiemTraDuLieu(maSP, tenSP, danhMuc, soLuong, donGia) {
    let hopLe = true;

    if (maSP.trim() === "") {
        document.getElementById("err-maSP").style.display = "block";
        hopLe = false;
    }

    if (tenSP.trim() === "") {
        document.getElementById("err-tenSP").style.display = "block";
        hopLe = false;
    }

    if (danhMuc.trim() === "") {
        document.getElementById("err-danhMuc").style.display = "block";
        hopLe = false;
    }

    const soLuongNum = Number(soLuong);
    if (soLuong.trim() === "" || !Number.isInteger(soLuongNum) || soLuongNum < 0) {
        document.getElementById("err-soLuong").style.display = "block";
        hopLe = false;
    }

    const donGiaNum = Number(donGia);
    if (donGia.trim() === "" || isNaN(donGiaNum) || donGiaNum <= 0) {
        document.getElementById("err-donGia").style.display = "block";
        hopLe = false;
    }

    return hopLe;
}

function themSanPham() {
    anTatCaLoi();

    const maSP = document.getElementById("maSP").value;
    const tenSP = document.getElementById("tenSP").value;
    const danhMuc = document.getElementById("danhMuc").value;
    const soLuong = document.getElementById("soLuong").value;
    const donGia = document.getElementById("donGia").value;

    const hopLe = kiemTraDuLieu(maSP, tenSP, danhMuc, soLuong, donGia);

    if (!hopLe) {
        return;
    }

    const sanPhamMoi = {
        maSP: maSP.trim(),
        tenSP: tenSP.trim(),
        danhMuc: danhMuc.trim(),
        soLuong: Number(soLuong),
        donGia: Number(donGia)
    };

    products.push(sanPhamMoi);

    isShowDanhSach = true;
    hienThiDanhSach();

    document.getElementById("maSP").value = "";
    document.getElementById("tenSP").value = "";
    document.getElementById("danhMuc").value = "";
    document.getElementById("soLuong").value = "";
    document.getElementById("donGia").value = "";

    alert("Thêm sản phẩm \"" + sanPhamMoi.tenSP + "\" thành công!");
}

window.onload = function () {
    hienThiDanhSach();
};